<?php
define('DB_HOST', 'mysql');
define('DB_USER', 'root');
define('DB_PASS', 'rootpassword');
define('DB_NAME', 'circumcision_system_db');
?>