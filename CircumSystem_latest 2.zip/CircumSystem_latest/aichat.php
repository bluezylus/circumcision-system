<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();
ob_start();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>AI Chat</title>
    <style>
        
        .sidebar {
            width: 200px;
            background-color: #2f3e46;
            color: white;
            padding-top: 20px;
        }

        .sidebar a {
            display: block;
            color: white;
            padding: 12px;
            text-decoration: none;
        }

        .sidebar a:hover {
            background-color: #354f52;
        }

        .chat-container {
            flex: 1;
            display: flex;
            flex-direction: column;
            background-color: #f1f1f1;
        }

        .chat-header {
            background-color: #52796f;
            color: white;
            padding: 15px;
            font-size: 20px;
        }

        .chat-box {
            flex: 1;
            padding: 20px;
            overflow-y: auto;
        }

        .chat-input-area {
            display: flex;
            padding: 15px;
            background-color: #cad2c5;
        }

        .chat-input-area input {
            flex: 1;
            padding: 10px;
            font-size: 16px;
            border: none;
            border-radius: 5px;
        }

        .chat-input-area button {
            margin-left: 5px;
            padding: 20px 10px;
            font-size: 16px;
            background-color: #354f52;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            width: 10%;
        }

        .chat-input-area button:hover {
            background-color: #2f3e46;
        }

        .chat-box button {
            margin: 5px;
            padding: 10px 15px;
            border: none;
            background-color: #52796f;
            color: white;
            border-radius: 5px;
            cursor: pointer;
        }

        .chat-box button:hover {
            background-color: #354f52;
        }

    </style>
</head>
<body>

<div class="chat-box" id="chatBox">
    <div><strong>👋 Hi! I’m your Circumcision Aftercare Assistant. What would you like to talk about today?</strong></div>
    <p>Please choose a category below:</p>

    <div id="options">
        <button onclick="selectCategory('Pain & Swelling')">✅ Pain & Swelling</button>
        <button onclick="selectCategory('Cleaning & Hygiene')">🚿 Cleaning & Hygiene</button>
        <button onclick="selectCategory('Wound Care & Ointments')">🧼 Wound Care & Ointments</button>
        <button onclick="selectCategory('Bleeding or Infection')">🩸 Bleeding or Infection</button>
        <button onclick="selectCategory('Healing & Recovery Time')">📅 Healing & Recovery Time</button>
        <button onclick="selectCategory('Others')">❓ Others</button>
    </div>
</div>

<script>
    function selectCategory(category) {
        const chatBox = document.getElementById("chatBox");
        const options = document.getElementById("options");
        options.remove(); // remove buttons after selection

        const userMsg = document.createElement("div");
        userMsg.innerHTML = `<strong>You:</strong> ${category}`;
        chatBox.appendChild(userMsg);

        // Custom AI flow for "Pain & Swelling"
        if (category === "Pain & Swelling") {
            const aiMsg = document.createElement("div");
            aiMsg.innerHTML = `
                <strong>🤖 AI:</strong> Is the child or patient experiencing pain right now?<br>
                <button onclick="answerPain('Yes')">Yes</button>
                <button onclick="answerPain('No')">No</button>
            `;
            chatBox.appendChild(aiMsg);
        } else {
            const aiMsg = document.createElement("div");
            aiMsg.innerHTML = `<strong>🤖 AI:</strong> Thank you for choosing <em>${category}</em>. I’m still learning to respond to this topic. Please check back later!`;
            chatBox.appendChild(aiMsg);
        }

        chatBox.scrollTop = chatBox.scrollHeight;
    }

    function answerPain(answer) {
        const chatBox = document.getElementById("chatBox");
        const userAnswer = document.createElement("div");
        userAnswer.innerHTML = `<strong>You:</strong> ${answer}`;
        chatBox.appendChild(userAnswer);

        if (answer === "Yes") {
            const aiReply = document.createElement("div");
            aiReply.innerHTML = `
                <strong>🤖 AI:</strong> Pain or discomfort for 1–2 days after circumcision is normal. You can give the prescribed medicine or paracetamol. Avoid tight clothing.<br>
                Would you like tips on how to reduce swelling?<br>
                <button onclick="reduceSwelling('Yes')">Yes</button>
                <button onclick="reduceSwelling('No')">No</button>
            `;
            chatBox.appendChild(aiReply);
        } else {
            const aiReply = document.createElement("div");
            aiReply.innerHTML = `<strong>🤖 AI:</strong> That’s great! If pain starts later or worsens, let a healthcare provider know.`;
            chatBox.appendChild(aiReply);
        }

        chatBox.scrollTop = chatBox.scrollHeight;
    }

    function reduceSwelling(answer) {
        const chatBox = document.getElementById("chatBox");
        const userAnswer = document.createElement("div");
        userAnswer.innerHTML = `<strong>You:</strong> ${answer}`;
        chatBox.appendChild(userAnswer);

        if (answer === "Yes") {
            const aiFinal = document.createElement("div");
            aiFinal.innerHTML = `
                <strong>🤖 AI:</strong> ✅ Apply a cold compress gently (wrapped in a clean cloth) for a few minutes. Elevate the area if possible and ensure the patient is resting.
            `;
            chatBox.appendChild(aiFinal);
        } else {
            const aiFinal = document.createElement("div");
            aiFinal.innerHTML = `<strong>🤖 AI:</strong> Got it. Let me know if you need anything else.`;
            chatBox.appendChild(aiFinal);
        }

        chatBox.scrollTop = chatBox.scrollHeight;
    }
</script>

</body>
</html>

<?php
$content = ob_get_clean();

// Render the page with the content
render_page($content, '');
?>