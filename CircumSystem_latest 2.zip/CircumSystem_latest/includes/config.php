<?php
define('BASE_PATH', dirname(__DIR__));
// Start session if not already started
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Database connection
define('DB_HOST', 'mysql');
define('DB_USER', 'root');
define('DB_PASS', 'rootpassword');
define('DB_NAME', 'circumcision_system_db');
$GLOBALS['conn'] = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if ($GLOBALS['conn']->connect_error) {
    die("Connection failed: " . $GLOBALS['conn']->connect_error);
}

require_once BASE_PATH . '/layouts/functions.php';