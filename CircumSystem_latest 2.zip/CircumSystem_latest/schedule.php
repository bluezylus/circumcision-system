<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();

$message = '';
$error = '';

// Get patient_id from patients table
$patient_query = "SELECT id FROM patients WHERE user_id = ?";
$patient_stmt = $conn->prepare($patient_query);
$patient_stmt->bind_param("i", $_SESSION['user_id']);
$patient_stmt->execute();
$patient_result = $patient_stmt->get_result();
$patient = $patient_result->fetch_assoc();
$patient_stmt->close();

if (!$patient) {
    $error = "Please submit consent form first!";
} else {
    $patient_id = $patient['id'];

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $time_slot = $conn->real_escape_string($_POST['date'] . ' ' . $_POST['time']);
        
        // Check if the patient already has an appointment at this time
        $check_sql = "SELECT COUNT(*) as count FROM schedule 
                      WHERE patient_id = ? AND time_slot = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("is", $patient_id, $time_slot);
        $check_stmt->execute();
        $result = $check_stmt->get_result();
        $row = $result->fetch_assoc();
        
        if ($row['count'] > 0) {
            $error = "You already have an appointment request for this time slot.";
        } else {
            // Insert the appointment request
            $sql = "INSERT INTO schedule (patient_id, time_slot, create_at, status) 
                    VALUES (?, ?, NOW(), 'pending')";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("is", $patient_id, $time_slot);
            
            if ($stmt->execute()) {
                $message = "Appointment request submitted successfully! Please wait for admin approval.";
            } else {
                $error = "Error submitting appointment request: " . $stmt->error;
            }
            $stmt->close();
        }
        $check_stmt->close();
    }

    // Fetch user's appointments
    $appointments_sql = "SELECT s.*, 
                        CONCAT(d.first_name, ' ', d.last_name) as doctor_name,
                        d.specialization
                        FROM schedule s
                        LEFT JOIN doctors d ON s.doctor_id = d.id
                        WHERE s.patient_id = ?
                        ORDER BY s.time_slot DESC";
    $appointments_stmt = $conn->prepare($appointments_sql);
    $appointments_stmt->bind_param("i", $patient_id);
    $appointments_stmt->execute();
    $appointments_result = $appointments_stmt->get_result();
}

ob_start();
?>
<style>
    <?php include 'style.css'; ?>
    .card {
        max-width: 800px;
        margin: 20px auto;
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    .alert {
        padding: 15px;
        margin-bottom: 20px;
        border: 1px solid transparent;
        border-radius: 4px;
    }
    .alert-success {
        color: #3c763d;
        background-color: #dff0d8;
        border-color: #d6e9c6;
    }
    .alert-danger {
        color: #a94442;
        background-color: #f2dede;
        border-color: #ebccd1;
    }
    .form-group {
        margin-bottom: 15px;
    }
    .form-group label {
        display: block;
        margin-bottom: 5px;
    }
    .form-control {
        width: 100%;
        padding: 8px;
        border: 1px solid #ddd;
        border-radius: 4px;
    }
    .btn {
        background-color: #52796f;
        color: white;
        padding: 10px 20px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
    }
    .btn:hover {
        background-color: #354f52;
    }
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    th, td {
        padding: 12px;
        text-align: left;
        border-bottom: 1px solid #ddd;
    }
    th {
        background-color: #52796f;
        color: white;
    }
    tr:nth-child(even) {
        background-color: #f9f9f9;
    }
    .status-pending {
        color: #856404;
        background-color: #fff3cd;
        padding: 4px 8px;
        border-radius: 4px;
    }
    .status-approved {
        color: #155724;
        background-color: #d4edda;
        padding: 4px 8px;
        border-radius: 4px;
    }
    .status-denied {
        color: #721c24;
        background-color: #f8d7da;
        padding: 4px 8px;
        border-radius: 4px;
    }
</style>

<div class="app-content">
    <div class="container-fluid">
        <?php if ($message): ?>
            <div class="alert alert-success"><?= $message ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <div class="card">
            <form method="POST">
                <div class="form-group">
                    <label for="date">Preferred Date:</label>
                    <input type="date" id="date" name="date" class="form-control" required 
                           min="<?= date('Y-m-d') ?>">
                </div>

                <div class="form-group">
                    <label for="time">Preferred Time:</label>
                    <select id="time" name="time" class="form-control" required>
                        <option value="">Select time...</option>
                        <?php
                        $start = strtotime('09:00');
                        $end = strtotime('17:00');
                        $interval = 30 * 60; // 30 minutes
                        
                        for ($time = $start; $time <= $end; $time += $interval) {
                            $time_slot = date('H:i', $time);
                            echo "<option value='$time_slot'>$time_slot</option>";
                        }
                        ?>
                    </select>
                </div>

                <div class="form-group">
                    <center>
                <button type="submit" class="btn" style="text-align: center; width: 250px;">Submit Request</button>
                    </center>
                </div>
            </form>
        </div>

        <div class="card">
            <h3>Your Appointment Requests</h3>
            <?php if (@$appointments_result->num_rows > 0): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Date & Time</th>
                            <th>Doctor</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php while ($appointment = $appointments_result->fetch_assoc()): ?>
                            <tr>
                                <td><?= date('F j, Y g:i A', strtotime($appointment['time_slot'])) ?></td>
                                <td>
                                    <?php if ($appointment['doctor_name']): ?>
                                        Dr. <?= htmlspecialchars($appointment['doctor_name']) ?>
                                    <?php else: ?>
                                        Not assigned yet
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php
                                    $status_class = '';
                                    switch ($appointment['status']) {
                                        case 'pending':
                                            $status_class = 'status-pending';
                                            break;
                                        case 'approved':
                                            $status_class = 'status-approved';
                                            break;
                                        case 'denied':
                                            $status_class = 'status-denied';
                                            break;
                                    }
                                    ?>
                                    <span class="<?= $status_class ?>">
                                        <?= ucfirst(htmlspecialchars($appointment['status'])) ?>
                                    </span>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>No appointment requests found.</p>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
// Set minimum date to today
document.getElementById('date').min = new Date().toISOString().split('T')[0];

// Disable past times for today
document.getElementById('date').addEventListener('change', function() {
    const timeSelect = document.getElementById('time');
    const selectedDate = this.value;
    const today = new Date().toISOString().split('T')[0];
    const now = new Date();
    
    Array.from(timeSelect.options).forEach(option => {
        if (selectedDate === today) {
            const [hours, minutes] = option.value.split(':');
            const optionTime = new Date();
            optionTime.setHours(hours, minutes);
            
            if (optionTime < now) {
                option.disabled = true;
            } else {
                option.disabled = false;
            }
        } else {
            option.disabled = false;
        }
    });
});
</script>

<?php
$content = ob_get_clean();

// Render the page with the content
render_page($content, 'Request Appointment');
?>