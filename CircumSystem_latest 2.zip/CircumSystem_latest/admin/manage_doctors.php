<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();

$message = '';

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        switch ($_POST['action']) {
            case 'add':
                $first_name = $conn->real_escape_string($_POST['first_name']);
                $last_name = $conn->real_escape_string($_POST['last_name']);
                $specialization = $conn->real_escape_string($_POST['specialization']);
                $license = $conn->real_escape_string($_POST['license']);
                $contract = $conn->real_escape_string($_POST['contract']);
                $affiliation = $conn->real_escape_string($_POST['affiliation']);
                $sql = "INSERT INTO doctors (first_name, last_name, specialization, license_number, contract, affiliation) 
                        VALUES ('$first_name', '$last_name', '$specialization', '$license', '$contract', '$affiliation')";
                
                if ($conn->query($sql)) {
                    $message = "Doctor added successfully!";
                } else {
                    $message = "Error adding doctor: " . $conn->error;
                }
                break;

            case 'update':
                $id = (int)$_POST['id'];
                $first_name = $conn->real_escape_string($_POST['first_name']);
                $last_name = $conn->real_escape_string($_POST['last_name']);
                $specialization = $conn->real_escape_string($_POST['specialization']);
                $license = $conn->real_escape_string($_POST['license']);
                $contract = $conn->real_escape_string($_POST['contract']);
                $affiliation = $conn->real_escape_string($_POST['affiliation']);
                $sql = "UPDATE doctors SET 
                        first_name = '$first_name',
                        last_name = '$last_name',
                        specialization = '$specialization',
                        license_number = '$license',
                        contract = '$contract'
                        affiliation = '$affiliation'
                        WHERE id = $id";
                
                if ($conn->query($sql)) {
                    $message = "Doctor updated successfully!";
                } else {
                    $message = "Error updating doctor: " . $conn->error;
                }
                break;

            case 'delete':
                $id = (int)$_POST['id'];
                $sql = "DELETE FROM doctors WHERE id = $id";
                
                if ($conn->query($sql)) {
                    $message = "Doctor deleted successfully!";
                } else {
                    $message = "Error deleting doctor: " . $conn->error;
                }
                break;
        }
    }
}

// Fetch all doctors
$sql = "SELECT * FROM doctors ORDER BY last_name, first_name";
$result = $conn->query($sql);

ob_start();
?>
    <style>
        <?php include '../style.css'; ?>
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #52796f;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f1f1f1;
        }
        .content {
            padding: 20px;
            flex: 1;
        }
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border: 1px solid transparent;
            border-radius: 4px;
        }
        .alert-success {
            color: #3c763d;
            background-color: #dff0d8;
            border-color: #d6e9c6;
        }
        .alert-danger {
            color: #a94442;
            background-color: #f2dede;
            border-color: #ebccd1;
        }
    </style>

<div class="app-content">
    <div class="container-fluid">
        <?php if ($message): ?>
            <div class="alert <?= strpos($message, 'Error') === 0 ? 'alert-danger' : 'alert-success' ?>">
                <?= htmlspecialchars($message) ?>
            </div>
        <?php endif; ?>

        <button onclick="showAdd()" style="width: 150px;" class="form-control">Add New Doctor</button>
        
        <div id="form-doctor" class="container-fluid col-md-4 d-none">
            <div class="card">
                <div class="card-body">
                    <h4 id="form-title">Add New Doctor</h4>
                    <form method="POST" id="doctor-form">
                        <input type="hidden" name="action" id="form-action" value="add">
                        <input type="hidden" name="id" id="doctor-id">
                        
                        <div class="form-group">
                            <label for="first_name">First Name:</label>
                            <input id="first_name" class="form-control" type="text" name="first_name" required />
                        </div>

                        <div class="form-group">
                            <label for="last_name">Last Name:</label>
                            <input id="last_name" class="form-control" type="text" name="last_name" required />
                        </div>

                        <div class="form-group">
                            <label for="specialization">Specialization:</label>
                            <input id="specialization" class="form-control" type="text" name="specialization" required />
                        </div>

                        <div class="form-group">
                            <label for="license">License No:</label>
                            <input id="license" class="form-control" type="text" name="license" required />
                        </div>

                        <div class="form-group">
                            <label for="contract">Contract:</label>
                            <input id="contract" class="form-control" type="text" name="contract" required />
                        </div>
                        <div class="form-group">
                            <label for="affiliation">Affiliation:</label>
                            <input id="affiliation" class="form-control" type="text" name="affiliation" required />
                        </div>
                        <div class="form-group text-center pt-4">
                            <button type="submit" class="btn">Submit</button>
                            <button type="button" class="btn" onclick="hideForm()">Cancel</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <?php if ($result && $result->num_rows > 0): ?>
        <table>
            <thead>
                <tr>
                    <th>Full Name</th>
                    <th>Specialization</th>
                    <th>License No</th>
                    <th>Contract</th>
                    <th>Affiliation</th>
                    <th style="width: 150px;">Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td><?= htmlspecialchars($row['first_name']) ?> <?= htmlspecialchars($row['last_name']) ?></td>
                        <td><?= htmlspecialchars($row['specialization']) ?></td>
                        <td><?= htmlspecialchars($row['license_number']) ?></td>
                        <td><?= htmlspecialchars($row['contract']) ?></td>
                        <td><?= htmlspecialchars($row['affiliation']) ?></td>
                        <td>
                            <button onclick="editDoctor(<?= htmlspecialchars(json_encode($row)) ?>)" class="btn btn-sm">Edit</button>
                            <button onclick="deleteDoctor(<?= $row['id'] ?>)" class="btn btn-sm">Delete</button>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    <?php else: ?>
        <p style="text-align: center; margin-top: 10%;">No doctors records found.</p>
    <?php endif; ?>
    </div>
</div>

<script>
function showAdd() {
    document.getElementById('form-title').textContent = 'Add New Doctor';
    document.getElementById('form-action').value = 'add';
    document.getElementById('doctor-id').value = '';
    document.getElementById('doctor-form').reset();
    document.getElementById('form-doctor').classList.remove('d-none');
}

function hideForm() {
    document.getElementById('form-doctor').classList.add('d-none');
}

function editDoctor(doctor) {
    document.getElementById('form-title').textContent = 'Edit Doctor';
    document.getElementById('form-action').value = 'update';
    document.getElementById('doctor-id').value = doctor.id;
    document.getElementById('first_name').value = doctor.first_name;
    document.getElementById('last_name').value = doctor.last_name;
    document.getElementById('specialization').value = doctor.specialization;
    document.getElementById('license').value = doctor.license_number;
    document.getElementById('contract').value = doctor.contract;
    document.getElementById('affiliation').value = doctor.affiliation;
}

function deleteDoctor(id) {
    if (confirm('Are you sure you want to delete this doctor?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="${id}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}
</script>
<?php 
$conn->close();
$content = ob_get_clean();

// Render the page with the content
render_page($content, 'Manage Doctors');
?>