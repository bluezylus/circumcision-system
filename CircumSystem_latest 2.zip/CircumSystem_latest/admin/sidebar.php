<nav style="width: 200px; float: left; padding: 20px; background: #f5f5f5; height: 100vh;">
    <ul style="list-style-type: none; padding: 0;">
        <li><a href="manage_patients.php">Manage Patients</a></li>
        <li><a href="edit_faqs.php">Manage FAQs</a></li>
        <li><a href="appointments.php">Appointments</a></li>
        <li><a href="reports.php">Reports</a></li>
        <li><a href="consent_uploads.php">Consent Uploads</a></li>
        <li><a href="chatbot_logs.php">AI Chat Logs</a></li>
        <li><a href="../logout.php">Logout</a></li>
    </ul>
</nav>