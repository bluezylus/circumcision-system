<?php
session_start();

$admin_credentials = [
    "admin" => "123"
];

function isValidAdmin($username, $password, $admin_credentials) {
    return isset($admin_credentials[$username]) && $admin_credentials[$username] === $password;
}

$error = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (isValidAdmin($username, $password, $admin_credentials)) {
        $_SESSION['admin'] = $username;
        $_SESSION['admin_logged_in'] = true;
        header("Location: admin.php");
        exit();
    } else {
        $error = "Invalid admin credentials.";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Login</title>
    <style>
        <?php include '../style.css'; ?>
    </style>
</head>
<body>
    <div class="form-container">
        <img src="/images/logo2.png" alt="System Logo" class="logo">

        <?php if (!empty($error)): ?>
            <p style="color: red; font-weight: bold;"><?php echo $error; ?></p>
        <?php endif; ?>

        <form method="post" action="admin_login.php">
            <input type="text" name="username" placeholder="Admin Username" required><br>
            <input type="password" name="password" placeholder="Password" required><br>
            <button type="submit">Log in as Admin</button>
        </form>

        <p><a href="login.php">Back to User Login</a></p>
    </div>
</body>
</html>