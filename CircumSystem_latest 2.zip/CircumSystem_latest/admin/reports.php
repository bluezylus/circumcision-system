<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();

ob_start();
?>
<style>
    <?php include '../style.css'; ?>

    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f0f4f8;
        margin: 0;
        padding: 0;
    }

    .content {
        padding: 40px;
        max-width: 1200px;
        margin: auto;
    }

    .content > p {
        font-size: 18px;
        margin-bottom: 30px;
    }

    .report-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
    }

    .report-box {
        background-color: white;
        padding: 25px;
        border-radius: 12px;
        box-shadow: 0 6px 12px rgba(0, 0, 0, 0.08);
        transition: transform 0.2s ease;
        border-left: 6px solid #52796f;
    }

    .report-box:hover {
        transform: translateY(-5px);
    }

    .report-box h3 {
        margin-top: 0;
        color: #354f52;
    }

    .report-box p {
        font-size: 16px;
        margin: 10px 0 0;
        color: #333;
    }

    .report-box strong {
        font-size: 20px;
        color: #1e6091;
    }
</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reports</title>
</head>
<body>
    <div class="content">
        <p>📊 Below is a summary of system activity:</p>

        <div class="report-grid">
            <div class="report-box">
                <h3>📅 Appointments Count</h3>
                <?php
                $result = $conn->query("SELECT COUNT(*) AS total FROM schedule");
                $row = $result->fetch_assoc();
                echo "<p>Total Appointments: <strong>" . $row['total'] . "</strong></p>";
                ?>
            </div>

            <div class="report-box">
                <h3>📝 Consent Form Uploads</h3>
                <?php
                $result = $conn->query("SELECT COUNT(*) AS uploaded FROM consent_uploads");
                $row = $result->fetch_assoc();
                echo "<p>Uploaded Consent Forms: <strong>" . $row['uploaded'] . "</strong></p>";
                ?>
            </div>

            <div class="report-box">
                <h3>👥 Registered Users</h3>
                <?php
                $result = $conn->query("SELECT COUNT(*) AS users FROM users");
                $row = $result->fetch_assoc();
                echo "<p>Total Registered Users: <strong>" . $row['users'] . "</strong></p>";
                ?>
            </div>
        </div>
    </div>
</body>
</html>
<?php 
$content = ob_get_clean();
render_page($content, 'Generate Reports');
?>
