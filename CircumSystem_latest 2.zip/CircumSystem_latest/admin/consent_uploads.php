<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();

$sql = "SELECT id, name, email, created_at FROM users WHERE role = 'user'";
$result = $conn->query($sql);

ob_start();
?>
<style>        
    <?php include '../style.css'; ?>
    table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        table, th, td {
            border: 1px solid #ccc;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #52796f;
            color: white;
        }
</style>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Consent Uploads</title>
</head>
<body>
    <div class="content">
        <table>
            <tr>
                <th>User</th>
                <th>File</th>
                <th>Date Submitted</th>
                <th>Download</th>
            </tr>

            <?php
            $query = "
                SELECT c.id, c.file_name, c.created_at, u.name 
                FROM consent_uploads c
                JOIN users u ON c.user_id = u.id
                ORDER BY c.created_at DESC
            ";
            $result = $conn->query($query);

            if ($result->num_rows > 0):
                while ($row = $result->fetch_assoc()):
            ?>
                <tr>
                    <td><?= htmlspecialchars($row['name']) ?></td>
                    <td><?= basename($row['file_name']) ?></td>
                    <td><?= $row['created_at'] ?></td>
                    <td><a class="download-btn" href="../<?= $row['file_name'] ?>" target="_blank">View/Download</a></td>
                </tr>
            <?php
                endwhile;
            else:
            ?>
                <tr><td colspan="4">No consent forms submitted yet.</td></tr>
            <?php endif; ?>
        </table>
    </div>
</body>
</html>
<?php 
$content = ob_get_clean();

// Render the page with the content
render_page($content, 'Consent Uploads');
?>