<nav class="mt-2">
  <ul
    class="nav sidebar-menu flex-column"
    data-lte-toggle="treeview"
    role="menu"
    data-accordion="false"
  >
    <li class="nav-item">
      <a href="/admin/admin.php" class="<?php echo get_nav_class('/admin/admin.php'); ?>">
        <p>📄 Dashboard</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/admin/manage_patients.php" class="<?php echo get_nav_class('/admin/manage_patients.php'); ?>">
        <p>👨‍⚕️ Manage Patients</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/admin/manage_doctors.php" class="<?php echo get_nav_class('/admin/manage_doctors.php'); ?>">
        <p>👨‍⚕️ Manage Doctors</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/admin/appointments.php" class="<?php echo get_nav_class('/admin/appointments.php'); ?>">
        <p>📅 Manage Appointments</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/admin/consent_uploads.php" class="<?php echo get_nav_class('/admin/consent_uploads.php'); ?>">
        <p>📄 Review & Consent IDs</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/admin/edit_faqs.php" class="<?php echo get_nav_class('/admin/edit_faqs.php'); ?>">
        <p>❓ Manage FAQs</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/admin/reports.php" class="<?php echo get_nav_class('/admin/reports.php'); ?>">
        <p>📊 Generate Reports</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/admin/chatbot_logs.php" class="<?php echo get_nav_class('/admin/chatbot_logs.php'); ?>">
        <p>🤖 AI Chat Logs</p>
      </a>
    </li>
  </ul>
</nav>