<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();

$error = "";
$success = "";

if (isset($_POST['add'])) {
    $question = trim($_POST['question']);
    $answer = trim($_POST['answer']);

    if ($question && $answer) {
        $stmt = $conn->prepare("INSERT INTO faqs (question, answer) VALUES (?, ?)");
        $stmt->bind_param("ss", $question, $answer);
        $stmt->execute();
        $success = "FAQ added!";
    } else {
        $error = "Please enter both question and answer.";
    }
}

if (isset($_GET['delete'])) {
    $id = intval($_GET['delete']);
    $conn->query("DELETE FROM faqs WHERE id = $id");
    $success = "FAQ deleted!";
}

$result = $conn->query("SELECT * FROM faqs ORDER BY id DESC");

ob_start();
?>

<style>
    <?php include '../style.css'; ?>
    .container {
        max-width: 700px;
        margin: auto;
        background: white;
        padding: 20px;
        border-radius: 10px;
    }

    h2 { text-align: center; }

    textarea, input[type="text"] {
        width: 100%;
        padding: 10px;
        margin-bottom: 10px;
        border: 1px solid #aaa;
        border-radius: 5px;
    }

    button {
        padding: 10px 20px;
        background: #0077cc;
        color: white;
        border: none;
        border-radius: 5px;
        cursor: pointer;
    }

    .faq-list {
        margin-top: 30px;
    }

    .faq-item {
        padding: 15px;
        background: #f1f1f1;
        border-radius: 5px;
        margin-bottom: 10px;
    }

    .faq-item form {
        display: inline;
    }

    .error { color: red; }
    .success { color: green; }
</style>

<div class="container">
    <h2>Edit FAQs</h2>

    <?php if ($error) echo "<p class='error'>$error</p>"; ?>
    <?php if ($success) echo "<p class='success'>$success</p>"; ?>

    <form method="POST">
        <input type="text" name="question" placeholder="Enter FAQ question" required>
        <textarea name="answer" rows="4" placeholder="Enter FAQ answer" required></textarea>
        <button type="submit" name="add">Add FAQ</button>
    </form>

    <div class="faq-list">
        <?php while ($row = $result->fetch_assoc()): ?>
            <div class="faq-item">
                <strong><?= htmlspecialchars($row['question']) ?></strong>
                <p><?= nl2br(htmlspecialchars($row['answer'])) ?></p>
                <form method="GET" style="display:inline;">
                    <input type="hidden" name="delete" value="<?= $row['id'] ?>">
                    <button type="submit" onclick="return confirm('Delete this FAQ?')">Delete</button>
                </form>
            </div>
        <?php endwhile; ?>
    </div>
</div>

<?php
$content = ob_get_clean();
// Render the page with the content
render_page($content, 'Edit FAQs');
?>
