<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();
ob_start();
?>

    <style>
        <?php include '../style.css'; ?>
        body {
            font-family: Arial, sans-serif;
            background-color: #f2f2f2;
        }

        .dashboard-container {
            max-width: 1000px;
            margin: 50px auto;
            background: white;
            padding: 30px;
            border-radius: 12px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        h1 {
            text-align: center;
            margin-bottom: 40px;
        }

        .card-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            padding: 10%;
        }

        .card {
            background: #e9f0ff;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            transition: 0.2s;
            text-decoration: none;
            color: #333;
            box-shadow: 2px 2px 10px rgba(0,0,0,0.05);
        }

        .card:hover {
            background-color: #d0e3ff;
            transform: translateY(-3px);
        }

        .logout-btn {
            display: block;
            text-align: right;
            margin-bottom: 10px;
        }

        .logout-btn a {
            color: red;
            text-decoration: none;
            font-weight: bold;
        }

        .logout-btn a:hover {
            text-decoration: underline;
        }
    </style>
<div class="app-content">
<div class="container-fluid">
        <div class="card-grid">
            <a class="card" href="/admin/manage_patients.php">👨‍⚕️ Manage Patients</a>
            <a class="card" href="/admin/manage_doctors.php">👨‍⚕️ Manage Doctors</a>
            <a class="card" href="/admin/appointments.php">📅 Manage Appointments</a>
            <a class="card" href="/admin/consent_uploads.php">📄 Review Consents & IDs</a>
            <a class="card" href="/admin/edit_faqs.php">❓ Manage FAQs</a>
            <a class="card" href="/admin/reports.php">📊 Generate Reports</a>
            <a class="card" href="/admin/chatbot_logs.php">🤖 AI Chat Logs</a>
        </div>
    </div>
    </div>
<?php
$content = ob_get_clean();

// Render the page with the content
render_page($content, 'Admin Dashboard');
?>