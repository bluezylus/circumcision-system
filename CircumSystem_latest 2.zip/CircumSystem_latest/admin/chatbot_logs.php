<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();

$sql = "SELECT id, name, email, created_at FROM users WHERE role = 'user'";
$result = $conn->query($sql);

ob_start();
?>
<style>
    <?php include '../style.css'; ?>
</style>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
</head>
<body>
    <main>
        <div class="chat-container">
            <div class="chat-messages" id="chatMessages">
                <p><strong>Bot:</strong> Hello! Ask me anything about circumcision.</p>
            </div>
        </div>
    </main>
    </script>
</body>
</html>
<?php
$content = ob_get_clean();

// Render the page with the content
render_page($content, 'AI Chat Logs');
?>