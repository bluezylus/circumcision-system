<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();

// Handle form submissions
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action'])) {
        $schedule_id = $_POST['schedule_id'];
        
        if ($_POST['action'] === 'update') {
            $doctor_id = !empty($_POST['doctor_id']) ? $_POST['doctor_id'] : null;
            $status = $_POST['status'];
            
            $sql = "UPDATE schedule SET doctor_id = ?, status = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("isi", $doctor_id, $status, $schedule_id);
            
            if ($stmt->execute()) {
                $message = "Appointment updated successfully!";
            } else {
                $error = "Error updating appointment: " . $conn->error;
            }
            $stmt->close();
        } elseif ($_POST['action'] === 'delete') {
            $sql = "DELETE FROM schedule WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $schedule_id);
            
            if ($stmt->execute()) {
                $message = "Appointment deleted successfully!";
            } else {
                $error = "Error deleting appointment: " . $conn->error;
            }
            $stmt->close();
        }
    }
}

// Fetch all appointments with patient and doctor information
$sql = "SELECT s.*, 
        p.first_name as patient_first_name, p.last_name as patient_last_name,
        d.first_name as doctor_first_name, d.last_name as doctor_last_name,
        d.specialization
        FROM schedule s
        LEFT JOIN patients p ON s.patient_id = p.id
        LEFT JOIN doctors d ON s.doctor_id = d.id
        ORDER BY s.time_slot DESC";
$result = $conn->query($sql);

// Fetch all doctors for the dropdown
$doctors_sql = "SELECT id, first_name, last_name, specialization FROM doctors";
$doctors_result = $conn->query($doctors_sql);
$doctors = [];
while ($row = $doctors_result->fetch_assoc()) {
    $doctors[] = $row;
}

ob_start();
?>

<style>
    <?php include '../style.css'; ?>
    table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }
    table, th, td {
        border: 1px solid #ccc;
    }
    th, td {
        padding: 12px;
        text-align: left;
    }
    th {
        background-color: #52796f;
        color: white;
    }
    tr:nth-child(even) {
        background-color: #f1f1f1;
    }
    .content {
        padding: 20px;
        flex: 1;
    }
    .alert {
        padding: 15px;
        margin-bottom: 20px;
        border: 1px solid transparent;
        border-radius: 4px;
    }
    .alert-success {
        color: #3c763d;
        background-color: #dff0d8;
        border-color: #d6e9c6;
    }
    .alert-danger {
        color: #a94442;
        background-color: #f2dede;
        border-color: #ebccd1;
    }
    .card {
        max-width: 1200px;
        margin: auto;
        background: white;
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        border: 0;
    }
    .btn {
        display: inline-block;
        font-weight: 400;
        text-align: center;
        white-space: nowrap;
        vertical-align: middle;
        user-select: none;
        border: 1px solid transparent;
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        line-height: 1.5;
        border-radius: 0.25rem;
        transition: color 0.15s ease-in-out, background-color 0.15s ease-in-out, border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
        margin: 0 2px;
    }
    .btn-sm {
        padding: 0.25rem 0.5rem;
        font-size: 0.875rem;
        line-height: 1.5;
        border-radius: 0.2rem;
    }
    .btn-approve {
        color: #fff;
        background-color: #28a745;
        border-color: #28a745;
    }
    .btn-deny {
        color: #fff;
        background-color: #dc3545;
        border-color: #dc3545;
    }
    .btn-reset {
        color: #fff;
        background-color: #6c757d;
        border-color: #6c757d;
    }
    .btn-danger {
        color: #fff;
        background-color: #dc3545;
        border-color: #dc3545;
    }
    .action-buttons {
        display: flex;
        gap: 4px;
    }
    .form-control {
        display: block;
        width: 100%;
        padding: 0.375rem 0.75rem;
        font-size: 1rem;
        line-height: 1.5;
        color: #495057;
        background-color: #fff;
        background-clip: padding-box;
        border: 1px solid #ced4da;
        border-radius: 0.25rem;
        transition: border-color 0.15s ease-in-out, box-shadow 0.15s ease-in-out;
    }
    .status-pending {
        color: #856404;
        background-color: #fff3cd;
        border-color: #ffeeba;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.875rem;
    }
    .status-approved {
        color: #155724;
        background-color: #d4edda;
        border-color: #c3e6cb;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.875rem;
    }
    .status-denied {
        color: #721c24;
        background-color: #f8d7da;
        border-color: #f5c6cb;
        padding: 0.25rem 0.5rem;
        border-radius: 0.25rem;
        font-size: 0.875rem;
    }
    .text-muted {
        color: #6c757d;
        font-size: 0.875rem;
    }
</style>

<div class="app-content">
    <div class="container-fluid">
        <?php if (isset($message)): ?>
            <div class="alert alert-success"><?= $message ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <?php if ($result->num_rows > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Patient Name</th>
                        <th>Date & Time</th>
                        <th>Doctor</th>
                        <th>Status</th>
                        <th>Assign Doctor</th>
                        <th style="width: 150px;">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td><?= htmlspecialchars($row['patient_first_name'] . ' ' . $row['patient_last_name']) ?></td>
                            <td><?= date('F j, Y g:i A', strtotime($row['time_slot'])) ?></td>
                            <td>
                                <?php if ($row['doctor_id']): ?>
                                    <?= htmlspecialchars($row['doctor_first_name'] . ' ' . $row['doctor_last_name']) ?>
                                    <br>
                                    <small class="text-muted"><?= htmlspecialchars($row['specialization']) ?></small>
                                <?php else: ?>
                                    <span class="text-muted">Not assigned</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <span class="status-<?= strtolower($row['status']) ?>">
                                    <?= ucfirst($row['status']) ?>
                                </span>
                            </td>
                            <td>
                                <form method="POST" class="d-inline" id="form-doctor-<?= $row['id'] ?>">
                                    <input type="hidden" name="schedule_id" value="<?= $row['id'] ?>">
                                    <input type="hidden" name="action" value="update">
                                    <input type="hidden" name="status" value="<?= $row['status'] ?>">
                                    
                                    <select name="doctor_id" class="form-control" onchange="validateAndSubmit(<?= $row['id'] ?>, 'doctor')">
                                        <option value="">Select Doctor</option>
                                        <?php foreach ($doctors as $doctor): ?>
                                            <option value="<?= $doctor['id'] ?>" <?= ($row['doctor_id'] == $doctor['id']) ? 'selected' : '' ?>>
                                                <?= htmlspecialchars($doctor['first_name'] . ' ' . $doctor['last_name'] . ' (' . $doctor['specialization'] . ')') ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                </form>
                            </td>
                            <td>
                                <form method="POST" class="d-inline" id="form-status-<?= $row['id'] ?>">
                                    <input type="hidden" name="schedule_id" value="<?= $row['id'] ?>">
                                    <input type="hidden" name="action" value="update">
                                    <input type="hidden" name="doctor_id" value="<?= $row['doctor_id'] ?>">
                                    <input type="hidden" name="status" value="<?= $row['status'] ?>">
                                    
                                    <div class="action-buttons">
                                        <?php if ($row['status'] === 'pending'): ?>
                                            <button type="button" class="btn btn-sm btn-approve" onclick="updateStatus(<?= $row['id'] ?>, 'approved')">Approve</button>
                                            <button type="button" class="btn btn-sm btn-deny" onclick="updateStatus(<?= $row['id'] ?>, 'denied')">Deny</button>
                                        <?php else: ?>
                                            <button type="button" class="btn btn-sm btn-reset" onclick="updateStatus(<?= $row['id'] ?>, 'pending')">Reset to Pending</button>
                                        <?php endif; ?>
                                        <button type="button" class="btn btn-sm btn-danger" onclick="deleteAppointment(<?= $row['id'] ?>)">Delete</button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        <?php else: ?>
            <p style="text-align: center; margin-top: 10%;">No appointments found.</p>
        <?php endif; ?>
    </div>
</div>

<script>
function validateAndSubmit(formId, type) {
    const form = document.getElementById('form-' + type + '-' + formId);
    const doctorSelect = document.querySelector('#form-doctor-' + formId + ' select[name="doctor_id"]');
    const statusInput = form.querySelector('input[name="status"]');
    
    // Only check for doctor if status is being changed to approved
    if (statusInput.value === 'approved') {
        // Check if a doctor is selected
        if (!doctorSelect.value) {
            alert('Please select a doctor before approving the appointment.');
            // Reset status to pending
            statusInput.value = 'pending';
            return;
        }
        // Update the doctor_id in the status form
        form.querySelector('input[name="doctor_id"]').value = doctorSelect.value;
    }
    
    // Submit the form
    form.submit();
}

function updateStatus(formId, newStatus) {
    const form = document.getElementById('form-status-' + formId);
    const statusInput = form.querySelector('input[name="status"]');
    statusInput.value = newStatus;
    validateAndSubmit(formId, 'status');
}

function deleteAppointment(formId) {
    if (confirm('Are you sure you want to delete this appointment? This action cannot be undone.')) {
        const form = document.getElementById('form-status-' + formId);
        form.querySelector('input[name="action"]').value = 'delete';
        form.submit();
    }
}
</script>

<?php
$content = ob_get_clean();
render_page($content, 'Manage Appointments');
?>