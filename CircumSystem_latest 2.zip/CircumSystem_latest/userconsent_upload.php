<?php
require_once 'includes/config.php';
require_once 'fpdf/fpdf.php';

// Redirect if not logged in
redirect_if_not_logged_in();

$message = "";
$error = "";

// Get user's name
$user_sql = "SELECT name FROM users WHERE id = ?";
$user_stmt = $conn->prepare($user_sql);
$user_stmt->bind_param("i", $_SESSION['user_id']);
$user_stmt->execute();
$user_result = $user_stmt->get_result();
$user = $user_result->fetch_assoc();
$user_stmt->close();

// Create uploads directory if it doesn't exist
if (!file_exists('uploads')) {
    mkdir('uploads', 0777, true);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $fullname = $conn->real_escape_string($_POST['fullname']);
    $dob = $conn->real_escape_string($_POST['dob']);
    $guardian = $conn->real_escape_string($_POST['guardian']);
    $relationship = $conn->real_escape_string($_POST['relationship']);
    
    // Handle file upload
    $uploaded_files = [];
    if (!empty($_FILES['documents']['name'][0])) {
        $allowed_types = ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'];
        $max_file_size = 5 * 1024 * 1024; // 5MB
        
        foreach ($_FILES['documents']['tmp_name'] as $key => $tmp_name) {
            $file_name = $_FILES['documents']['name'][$key];
            $file_size = $_FILES['documents']['size'][$key];
            $file_type = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
            
            // Validate file type
            if (!in_array($file_type, $allowed_types)) {
                $error = "Invalid file type. Allowed types: " . implode(', ', $allowed_types);
                continue;
            }
            
            // Validate file size
            if ($file_size > $max_file_size) {
                $error = "File size exceeds 5MB limit";
                continue;
            }
            
            // Generate unique filename
            $new_filename = 'uploads/consent_doc_' . time() . '_' . $key . '.' . $file_type;
            
            if (move_uploaded_file($tmp_name, $new_filename)) {
                $uploaded_files[] = $new_filename;
            } else {
                $error = "Error uploading file: " . $file_name;
            }
        }
    }

    // Generate PDF consent form
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', '', 12);
    $pdf->Cell(0, 10, "Consent Form", 0, 1, 'C');
    $pdf->Ln(10);

    $pdf->Cell(50, 10, "Child's Name:");
    $pdf->Cell(0, 10, $fullname, 0, 1);
    $pdf->Cell(50, 10, "Date of Birth:");
    $pdf->Cell(0, 10, $dob, 0, 1);
    $pdf->Cell(50, 10, "Guardian's Name:");
    $pdf->Cell(0, 10, $guardian, 0, 1);
    $pdf->Cell(50, 10, "Relationship to Child:");
    $pdf->Cell(0, 10, $relationship, 0, 1);

    $consent_filename = 'uploads/consent_' . time() . '.pdf';
    $pdf->Output('F', $consent_filename);

    // Start transaction
    $conn->begin_transaction();

    try {
        // Split full name into first and last name
        $name_parts = explode(' ', $fullname, 2);
        $first_name = $name_parts[0];
        $last_name = isset($name_parts[1]) ? $name_parts[1] : '';

        // First, create patient record
        $patient_sql = "INSERT INTO patients (user_id, first_name, last_name, birth_date) 
                       VALUES (?, ?, ?, ?)";
        $patient_stmt = $conn->prepare($patient_sql);
        $patient_stmt->bind_param("isss", $_SESSION['user_id'], $first_name, $last_name, $dob);
        $patient_stmt->execute();
        $patient_id = $conn->insert_id;
        $patient_stmt->close();

        // Then, store consent form
        $consent_sql = "INSERT INTO consent_uploads (user_id, user, file_name, uploaded_documents) 
                       VALUES (?, ?, ?, ?)";
        $uploaded_docs = !empty($uploaded_files) ? implode(',', $uploaded_files) : null;
        $consent_stmt = $conn->prepare($consent_sql);
        $consent_stmt->bind_param("isss", $_SESSION['user_id'], $fullname, $consent_filename, $uploaded_docs);
        $consent_stmt->execute();
        $consent_stmt->close();

        // If everything is successful, commit the transaction
        $conn->commit();
        
        $message = "Consent form and patient profile submitted successfully. ";
        $message .= "<a href='$consent_filename' target='_blank'>Download Consent PDF</a>";
        
        if (!empty($uploaded_files)) {
            $message .= "<br>Uploaded Documents:<br>";
            foreach ($uploaded_files as $file) {
                $message .= "<a href='$file' target='_blank'>" . basename($file) . "</a><br>";
            }
        }
    } catch (Exception $e) {
        // If there's an error, rollback the transaction
        $conn->rollback();
        $error = "Error: " . $e->getMessage();
    }
}

ob_start();
?>
<style>
.card {
    max-width: 700px;
    margin: auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    border: 0;
}
.alert {
    padding: 15px;
    margin-bottom: 20px;
    border: 1px solid transparent;
    border-radius: 4px;
}
.alert-success {
    color: #3c763d;
    background-color: #dff0d8;
    border-color: #d6e9c6;
}
.alert-danger {
    color: #a94442;
    background-color: #f2dede;
    border-color: #ebccd1;
}
.file-list {
    margin-top: 10px;
    padding: 10px;
    border: 1px dashed #ccc;
    border-radius: 4px;
    background: #f9f9f9;
}
</style>
<div class="app-content">
  <div class="container-fluid col-md-4">
    <div class="card">
    <div class="card-body">
        <?php if ($message): ?>
            <div class="alert alert-success"><?= $message ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="alert alert-danger"><?= $error ?></div>
        <?php endif; ?>

        <form method="POST" enctype="multipart/form-data">
            <div class="form-group">
                <label for="fullname">Child's Name:</label>
                <input id="fullname" class="form-control" type="text" name="fullname" required>
            </div>

            <div class="form-group">
                <label for="dob">Date of Birth:</label>
                <input id="dob" class="form-control" type="date" name="dob" required>
            </div>

            <div class="form-group">
                <label for="guardian">Guardian's Name:</label>
                <input id="guardian" class="form-control" type="text" name="guardian" value="<?= htmlspecialchars($user['name']) ?>" required readonly>
            </div>

            <div class="form-group">
                <label for="relationship">Relationship to Child:</label>
                <input id="relationship" class="form-control" type="text" name="relationship" required>
            </div>

            <div class="form-group">
                <label for="documents">Upload Supporting Documents:</label>
                <input id="documents" class="form-control" type="file" name="documents[]" multiple accept=".pdf,.jpg,.jpeg,.png,.doc,.docx">
                <small class="text-muted">Allowed file types: PDF, JPG, PNG, DOC, DOCX (Max size: 5MB each)</small>
                <div id="file-list" class="file-list d-none">
                    <p>Selected files:</p>
                    <ul id="selected-files"></ul>
                </div>
            </div>

            <div class="form-group text-center pt-4">
                <button type="submit" class="btn">Submit & Generate PDF</button>
            </div>
        </form>
    </div>
</div>
    </div>
</div>

<script>
document.getElementById('documents').addEventListener('change', function(e) {
    const fileList = document.getElementById('file-list');
    const selectedFiles = document.getElementById('selected-files');
    selectedFiles.innerHTML = '';
    
    if (this.files.length > 0) {
        fileList.classList.remove('d-none');
        Array.from(this.files).forEach(file => {
            const li = document.createElement('li');
            li.textContent = `${file.name} (${(file.size / 1024 / 1024).toFixed(2)} MB)`;
            selectedFiles.appendChild(li);
        });
    } else {
        fileList.classList.add('d-none');
    }
});
</script>

<?php
$content = ob_get_clean();

// Render the page with the content
render_page($content, 'Child Registration & Consent Form');
?>