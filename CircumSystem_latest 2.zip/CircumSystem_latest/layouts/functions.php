<?php
function render_page($content, $page_title = null) {
    // Start output buffering
    ob_start();
    
    // Include the master template
    include 'master.php';
    
    // Get the contents of the buffer
    $output = ob_get_clean();
    
    // Output the final page
    echo $output;
}

// Add any other helper functions here
function is_logged_in() {
    return isset($_SESSION['user_id']);
}

function redirect_if_not_logged_in() {
    if (!is_logged_in()) {
        header('Location: /login.php');
        exit();
    }
}

function is_current_page($path) {
    $current_page = $_SERVER['PHP_SELF'];
    return $current_page === $path;
}

function get_nav_class($path) {
    return is_current_page($path) ? 'nav-link active' : 'nav-link';
}