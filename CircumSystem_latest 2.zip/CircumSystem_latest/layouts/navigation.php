<nav class="mt-2">
  <ul
    class="nav sidebar-menu flex-column"
    data-lte-toggle="treeview"
    role="menu"
    data-accordion="false"
  >
    <li class="nav-item">
      <a href="/user_dashboard.php" class="<?php echo get_nav_class('/user_dashboard.php'); ?>">
        <i class="nav-icon bi bi-speedometer"></i>
        <p>Dashboard</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/faq.php" class="<?php echo get_nav_class('/faq.php'); ?>">
        <i class="nav-icon bi bi-patch-question"></i>
        <p>FAQ</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/aichat.php" class="<?php echo get_nav_class('/aichat.php'); ?>">
        <i class="nav-icon bi bi-robot"></i>
        <p>AI Chat</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/schedule.php" class="<?php echo get_nav_class('/schedule.php'); ?>">
        <i class="nav-icon bi bi-calendar-event"></i>
        <p>Schedule</p>
      </a>
    </li>
    <li class="nav-item">
      <a href="/userconsent_upload.php" class="<?php echo get_nav_class('/userconsent_upload.php'); ?>">
        <i class="nav-icon bi bi-file-earmark-medical"></i>
        <p>Consent Form</p>
      </a>
    </li>
  </ul>
</nav>