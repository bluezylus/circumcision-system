<footer class="app-footer">
  Copyright &copy; <?php echo date('Y'); ?>&nbsp RHU Online System. All rights reserved.
</footer>