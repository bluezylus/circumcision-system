<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();
ob_start();

// Fetch user's confirmed appointment
$sql = "SELECT s.*, 
        d.first_name as doctor_first_name, 
        d.last_name as doctor_last_name,
        d.specialization
        FROM schedule s
        LEFT JOIN doctors d ON s.doctor_id = d.id
        LEFT JOIN patients p ON s.patient_id = p.id
        LEFT JOIN users u ON p.user_id = u.id
        WHERE u.id = ? AND s.status = 'approved'
        ORDER BY s.time_slot DESC
        LIMIT 1";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $_SESSION['user_id']);
$stmt->execute();
$appointment_result = $stmt->get_result();
$has_appointment = $appointment_result->num_rows > 0;
$appointment = $has_appointment ? $appointment_result->fetch_assoc() : null;
$stmt->close();
?>
<style>
  .chat-box {
    max-width: 700px;
    margin: auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  }
</style>
<div class="app-content">
  <div class="container-fluid">
    <div class="chat-box">
      <?php if ($has_appointment): ?>
        <p><strong>Your confirmed appointment:</strong></p>
        <p>Date: <?= date('F j, Y', strtotime($appointment['time_slot'])) ?></p>
        <p>Time: <?= date('g:i A', strtotime($appointment['time_slot'])) ?></p>
        <p>Doctor: Dr. <?= htmlspecialchars($appointment['doctor_first_name'] . ' ' . $appointment['doctor_last_name']) ?></p>
        <p>Specialization: <?= htmlspecialchars($appointment['specialization']) ?></p>
      <?php else: ?>
        <p><strong>No appointment scheduled yet.</strong></p>
      <?php endif; ?>
      
      <ul style="list-style-type: none; padding: 0;">
        <li><a href="userconsent_upload.php">Upload Consent Form</a></li>
      </ul>
    </div>
  </div>
</div>
<?php
$content = ob_get_clean();

// Render the page with the content
render_page($content, 'Dashboard');
?>