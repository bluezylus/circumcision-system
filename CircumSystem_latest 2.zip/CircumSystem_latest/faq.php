<?php
require_once 'includes/config.php';

// Redirect if not logged in
redirect_if_not_logged_in();

$query = "SELECT * FROM faqs ORDER BY id DESC";
$result = $conn->query($query);

ob_start();
?>

<style>
.faq-container {
    max-width: 700px;
    margin: auto;
    background: white;
    padding: 20px;
    border-radius: 8px;
    box-shadow: 0 2px 10px rgba(0,0,0,0.1);
}

.faq-item {
    border-bottom: 1px solid #ddd;
    padding: 15px 0;
}

.faq-question {
    font-weight: bold;
    cursor: pointer;
    position: relative;
    padding-right: 30px;
}

.faq-question::after {
    content: "+";
    position: absolute;
    right: 0;
    font-weight: bold;
    transition: transform 0.3s ease;
}

.faq-question.active::after {
    content: "-";
}

.faq-answer {
    display: none;
    margin-top: 10px;
    color: #333;
    line-height: 1.6;
    transition: max-height 0.3s ease;
}
</style>

<div class="app-content">
  <div class="container-fluid">
  <div class="faq-container">
    <h2>Frequently Asked Questions</h2>

    <?php while ($row = $result->fetch_assoc()): ?>
        <div class="faq-item">
            <div class="faq-question" onclick="toggleAnswer(this)">
                <?= htmlspecialchars($row['question']) ?>
            </div>
            <div class="faq-answer">
                <?= nl2br(htmlspecialchars($row['answer'])) ?>
            </div>
        </div>
    <?php endwhile; ?>
    </div>
  </div>

    <script>
        function toggleAnswer(el) {
            el.classList.toggle("active");
            const answer = el.nextElementSibling;
            answer.style.display = answer.style.display === "block" ? "none" : "block";
        }
    </script>
</div>
<?php
$content = ob_get_clean();

// Render the page with the content
render_page($content, 'FAQ');
?>